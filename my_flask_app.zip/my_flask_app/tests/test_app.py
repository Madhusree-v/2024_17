import unittest
from app import create_app
from flask import url_for

class BasicTests(unittest.TestCase):
    def setUp(self):
        self.app = create_app('config.development.Config')
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()

    def tearDown(self):
        self.app_context.pop()

    def test_index(self):
        response = self.client.get(url_for('main.index'))
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Image Text Extraction', response.data)

    # Additional tests for upload functionality can be added here

if __name__ == '__main__':
    unittest.main()
