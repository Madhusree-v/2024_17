import os
from flask import Flask

def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(config_name)
    
    from app.routes.main_routes import main
    app.register_blueprint(main)
    
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])

    return app
