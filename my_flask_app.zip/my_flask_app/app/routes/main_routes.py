from flask import Blueprint, render_template, request, jsonify, current_app as app
from werkzeug.utils import secure_filename
import os
import json
from app.services.text_extraction import extract_text_from_image, extract_text_from_pdf
from app.utils.file_utils import allowed_file

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    if allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        if filename.lower().endswith('.pdf'):
            text = extract_text_from_pdf(file_path)
        else:
            text = extract_text_from_image(file_path)

        # Optionally clean up the uploaded file
        os.remove(file_path)

        json_output = json.dumps({'text': text}, indent=4)
        csv_output = 'text\n' + text.replace('\n', '\n')

        return jsonify({
            'text': text,
            'json': json_output,
            'csv': csv_output
        })
    return jsonify({'error': 'Invalid file type'}), 400
