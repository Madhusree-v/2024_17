class Config:
    SECRET_KEY = 'your_secret_key'
    UPLOAD_FOLDER = 'uploads/'
    DEBUG = False
